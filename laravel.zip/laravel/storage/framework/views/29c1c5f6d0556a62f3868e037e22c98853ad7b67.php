<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>购物车</title>
    <meta content="app-id=518966501" name="apple-itunes-app" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, user-scalable=no, maximum-scale=1.0" />
    <meta content="yes" name="apple-mobile-web-app-capable" />
    <meta content="black" name="apple-mobile-web-app-status-bar-style" />
    <meta content="telephone=no" name="format-detection" />
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="0" />
    <link href="css/comm.css" rel="stylesheet" type="text/css" />
    <link href="css/cartlist.css" rel="stylesheet" type="text/css" />
    <script src="/layui/layui.js" charset="utf-8"></script>
    <script src="js/jquery-1.11.2.min.js"></script>
</head>
<body id="loadingPicBlock" class="g-acc-bg">
<input name="hidUserID" type="hidden" id="hidUserID" value="-1" />
<div>
    <!--首页头部-->
    <div class="m-block-header">
        <a href="/" class="m-public-icon m-1yyg-icon"></a>
        <a href="/" class="m-index-icon">编辑</a>
    </div>
    <!--首页头部 end-->

    <div class="g-Cart-list">
        <?php if($goodsInfo): ?>
        <ul id="cartBody">
            <?php $__currentLoopData = $goodsInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li price="<?php echo e($v['shop_price']); ?>" id=<?php echo e($v['goods_id']); ?>>
                <s class="xuan current"></s>
                <a class="fl u-Cart-img" href="/goodscontent?goods_id=<?php echo e($v['goods_id']); ?>">
                    <img src="<?php echo e(URL::asset("uploads/".$v['goods_img'])); ?>" border="0" alt="">
                </a>
                <div class="u-Cart-r">
                    <a href="/goodscontent?goods_id=<?php echo e($v['goods_id']); ?>" class="gray6"><?php echo e($v['goods_name']); ?></a>
                        <span class="gray9">
                            <b>商品价格:</b><em class="price"><?php echo e($v['shop_price']); ?></em>
                        </span>
                    <div class="num-opt" goods_id="<?php echo e($v['goods_id']); ?>">
                        <em class="num-mius dis min"><i></i></em>
                        <input class="text_box" name="num" maxlength="6" type="text" goods_num="<?php echo e($v['goods_number']); ?>" value="<?php echo e($v['buy_number']); ?>" codeid="12501977">
                        <em class="num-add add"><i></i></em>
                    </div>
                    <a href="javascript:;" name="delLink" cid="12501977" isover="0"  class="z-del"><s></s></a>
                </div>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php else: ?>
        <div id="divNone" class="empty "  ><s></s><p>您的购物车还是空的哦~</p><a href="/goods" class="orangeBtn">立即潮购</a></div>
        <?php endif; ?>
    </div>
    <div id="mycartpay" class="g-Total-bt g-car-new" style="">
        <dl>
            <dt class="gray6">
                <s class="quanxuan current"></s>全选
            <p class="money-total">合计<em class="orange total"><span>￥</span><?php echo e($totalPrice); ?></em></p>

            </dt>
            <dd>
                <a href="javascript:;" id="a_payment" class="orangeBtn w_account remove">删除</a>
                <a href="javascript:;" name="pay" id="a_payment" class="orangeBtn w_account">去结算</a>
            </dd>
        </dl>
    </div>
    <div class="hot-recom">
        <div class="title thin-bor-top gray6">
            <span><b class="z-set"></b>人气推荐</span>
            <em></em>
        </div>
        <div class="goods-wrap thin-bor-top">
            <ul class="goods-list clearfix">
                <?php $__currentLoopData = $hotInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a href="/goodscontent?goods_id=<?php echo e($v->goods_id); ?>" class="g-pic">
                        <img src="<?php echo e(URL::asset("uploads/".$v->goods_img)); ?>" width="136" height="136">
                    </a>
                    <p class="g-name">
                        <a href="https://m.1yyg.com/v44/products/23458.do">(第<i><?php echo e($v->goods_id); ?></i>潮)<?php echo e($v->goods_name); ?></a>
                    </p>
                    <ins class="gray9">价值:￥<?php echo e($v->shop_price); ?></ins>
                    <div class="btn-wrap">
                        <div class="Progress-bar">
                            <p class="u-progress">
                                    <span class="pgbar" style="width:1%;">
                                        <span class="pging"></span>
                                    </span>
                            </p>
                        </div>
                        <div class="gRate" data-productid="23458">
                            <a href="javascript:;" id="<?php echo e($v->goods_id); ?>" ><s></s></a>
                        </div>
                    </div>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>




    <div class="footer clearfix">
        <ul>
            <li class="f_home"><a href="/index" ><i></i>潮购</a></li>
            <li class="f_announced"><a href="javacript:;" ><i></i>最新揭晓</a></li>
            <li class="f_single"><a href="javacript:;" ><i></i>晒单</a></li>
            <li class="f_car"><a id="btnCart" href="#" class="hover"><i></i>购物车</a></li>
            <li class="f_personal"><a href="/user" ><i></i>我的潮购</a></li>
        </ul>
    </div>


    <script>

            //加入购物车
            layui.use("layer",function(){
                var layer = layui.layer;
                //加入购物车
                $(".gRate a").click(function() {
                    var goods_id = $(this).attr("id");
                    var data = {};
                    var url = "/addcarts";
                    var refre = "/goodscontent?goods_id=" + goods_id;
                    var cartNum = $(".cart b").text();
                    data.goods_id = goods_id;
                    $.ajax({
                        type: "post",
                        url: url,
                        data: data,
                        dataType: "json",
                    }).done(function (msg) {
                        cartNum = parseInt(cartNum) + parseInt(1);
//                    0:未登录 1:商品下架   2  添加购物车成功  3 添加购物车失败
                        if (msg.code == 0) {
                            layer.confirm("执行该操作需先登录,确定要登录么?", {title: "您未登录"}, function () {
                                window.location.href = "/log?refre=" + refre + "goods_id=" + goods_id;
                            })
                        }
                        if (msg.code == 1) {
                            layer.msg(msg.msg, {time: 10000});
                        }
                        if (msg.code == 2) {

                            layer.msg(msg.msg, {time: 10000});
                            window.location.reload();
//
                            $(".cart b").text(cartNum)
                            $(".cart li b").attr("num", cartNum)

                        }
                        if (msg.code == 3) {
                            layer.msg(msg.msg, {time: 10000});
                            $(".cart li b").text(cartNum)
                            $(".cart li b").attr("num", cartNum)
                        }
                    })


                })


        })

    </script>



    <!---商品加减算总数---->
    <script type="text/javascript">

        $(function () {
            
            $(".add").click(function () {
                var t = $(this).prev();           //当前input框里的值
                var data = {};
                var goods_num = parseInt( $(this).prev().attr("goods_num") );
                var buy_num = parseInt( $(this).prev().val() );
                var url = "/updateNum";
                var buyNum = parseInt( buy_num )+parseInt(1);
                data.buyNum = buyNum;
                data.goods_id =parseInt( $(this).parent().attr("goods_id") );
                if(buyNum <= goods_num ){
                    $.ajax({
                        type : "post",
                        data :data,
                        url : url,
                        success : function( msg ){
                            ;if(msg.code==1){
                                t.val(parseInt(t.val()) + 1);
                                GetCount();
                            }
                        }
                    })
                }

            })
//            减购买数量
            $(".min").click(function () {
                var t = $(this).next();
                var data = {};
                var goods_num = parseInt( $(this).next().attr("goods_num") );
                var buy_num = parseInt( $(this).next().val() );
                var url = "/updateNum";
                var buyNum = parseInt( buy_num )-parseInt(1);
                data.buyNum = buyNum;
                data.goods_id =parseInt( $(this).parent().attr("goods_id") );

                if(t.val()>1){
                    $.ajax({
                        type : "post",
                        data :data,
                        url : url,
                        success : function( msg ){
                            ;if(msg.code==1){
                                t.val(parseInt(t.val()) - 1);
                                GetCount();
                            }
                        }
                    })

                }
            })

            //直接修改input框里的购买数量
            $(".text_box").blur(function(){
                var data = {};
                var obj = $(this);
                var goods_num = parseInt( $(this).attr("goods_num") );
                var buy_num = parseInt( $(this).val() );
                if(isNaN(buy_num)){
                    buy_num = 1;
                }
                if(buy_num > goods_num){
                    buy_num = goods_num;
                }
                if(buy_num <1){
                    buy_num = 1;
                }

                data.buyNum = buy_num;
                data.goods_id =parseInt( $(this).parent().attr("goods_id") );
                var url = "/updateNum";
//                if(buy_num <= goods_num && buy_num>0 ){
                    $.ajax({
                        type :"post",
                        data : data,
                        url : url,
                        success :function( msg ){
                            obj.val(buy_num);
                            GetCount();
                        }
                    })
//
            })
//            end
        })
    </script>




    <script>
        // 全选
        $(".quanxuan").click(function () {
            if($(this).hasClass('current')){
                $(this).removeClass('current');

                $(".g-Cart-list .xuan").each(function () {
                    if ($(this).hasClass("current")) {
                        $(this).removeClass("current");
                    } else {
                        $(this).addClass("current");
                    }
                });
                GetCount();
            }else{
                $(this).addClass('current');

                $(".g-Cart-list .xuan").each(function () {
                    $(this).addClass("current");
                    // $(this).next().css({ "background-color": "#3366cc", "color": "#ffffff" });
                });
                GetCount();
            }


        });
        // 单选
        $(".g-Cart-list .xuan").click(function () {
            if($(this).hasClass('current')){


                $(this).removeClass('current');

            }else{
                $(this).addClass('current');
            }
            if($('.g-Cart-list .xuan.current').length==$('#cartBody li').length){
                $('.quanxuan').addClass('current');

            }else{
                $('.quanxuan').removeClass('current');
            }
            // $("#total2").html() = GetCount($(this));
            GetCount();
            //alert(conts);
        });
        // 已选中的总额
        function GetCount() {
            var conts = 0;
            var aa = 0;
//            var shop_price = $(".price").text();

            $(".g-Cart-list .xuan").each(function () {
                if ($(this).hasClass("current")) {
                    for (var i = 0; i < $(this).length; i++) {
//                        conts += parseInt($(this).parents('li').find('input.text_box').val());

                        conts +=parseInt($(this).parents('li').find('input.text_box').val()) * $(this).parents('li').attr("price") ;
                        // aa += 1;
                    }
                }
            });

            $(".total").html('<span>￥</span>'+(conts).toFixed(2));
        }
        GetCount();
    </script>

    <script>
        
        $("[name='delLink']").click(function(){              //单删
            var data = {};
            var url = "/del";
            data.goods_id =$(this).prev().attr("goods_id");
            layui.use("layer",function(){               //使用layui
                var layer = layui.layer;
                layer.confirm("您确定要删除么?",{title:"温馨提示"},function(){
                    $.ajax({
                        type :"post",
                        data : data,
                        url : url,
                        success :function( msg ){
                            if(msg.code==1){
                                layer.msg(msg.msg,{time:7000});
                                window.location.reload();
                            }
                        }
                    })
                })
            })

//        单删结束
        })

        $(".remove").click(function(){
            var idval = Array();
            var url = "/del";
            $(".g-Cart-list .xuan").each(function(){
                if($(this).hasClass("current")){
                    idval.push(parseInt($(this).parents("li").attr("id")));
                }
            })
            var len = idval.length;

            if(len == 0){
                alert("请选择您要删除的数据");
            }else{
                layui.use("layer",function(){
                    var layer = layui.layer;
                    layer.confirm("您确定要全部删除么?",{title :"温馨提示"},function(){
                        $.ajax({
                            type :"post",
                            data : {idval :idval},
                            url :url,
                            success :function(msg){
                                if(msg.code==1){
                                    layer.msg(msg.msg,{time :4000});
                                    window.location.reload();
                                }
                            }
                        })
                    })


                })
            }

        })

    </script>
    
    <script>
        $("[name='pay']").click(function(){
            var url = "/payInfo";
            var idval = [];
            var data = {};
            $(".g-Cart-list .xuan").each(function(){
                    if($(this).hasClass("current")){
                        idval.push($(this).parent().attr("id"))
                    }
            })
            data.idval = idval;
            layui.use("layer",function(){
                var layer = layui.layer;
                if( idval==""){
                    layer.msg("请选择您要购买的商品");
                    return false;
                }
                var refre = "/buycart";
                $.ajax({
                    type :"post",
                    url :url,
                    data : data,
                    dataType :"json",
                    success :function( msg ){
                        if(msg.code==0){     //未登录
                            layer.confirm("执行该操作需登录,您要登录么?",{title:"温馨提示"},function(){
                                window.location.href ="/log?refre="+refre;
                                return false;
                            })
                        }else if(msg.code==1){
                            layer.msg(msg.msg,{time:3000});
                            return false;
                        }else if(msg.code==3 ){
                            layer.msg(msg.msg,{time:4000});
                            window.location.href = "/orderIndex?order="+msg.refre;
                        }




                    }

                })
            })




        })
    </script>
</div>
</body>
</html>
