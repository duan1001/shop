<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>商品展示页面</title>
    <link rel="stylesheet" href="js/bootstrap.min.css">
</head>
<body>

    <div style="margin-top: 5px">

    是否热销:
    <select name="is_hot" id="">

        <option value="1">是</option>
        <option value="2">否</option>
    </select>
    是否上架:
    <select name="is_sole" id="">

        <option value="1">是</option>
        <option value="2">否</option>
    </select>
        <input type="button" value="搜索" id="search">
        
    </div>

    <table border="1" style="margin-top: 20px">
        <thead>
        <tr>
            <th>编号</th>
            <th>名称</th>
            <th>分类</th>
            <th>描述</th>
            <th>是否热门</th>
            <th>是否上架</th>
            <th>操作</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($v->id); ?></td>
            <td  val="name" id="<?php echo e($v->id); ?>"><span class="up"><?php echo e($v->name); ?></span></td>
            <td><?php echo e($v->cate_name); ?></td>
            <td><?php echo e($v->disc); ?></td>
            <td val="is_hot" id="<?php echo e($v->id); ?>"><span class="up"><?php if($v->is_hot ==1){ echo '是';}else{echo '否';} ?></span></td>
            <td val="is_sole" id="<?php echo e($v->id); ?>"><span class="up"><?php if($v->is_sole ==1){ echo '是';}else{echo '否';} ?> </span></td>
            <td>
                <a href="javascript:;" onclick="del(<?php echo e($v->id); ?>)">删除</a>
                <a href="upd?id=<?php echo e($v->id); ?>">修改</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>
<div class="page"><?php echo e($arr->links()); ?></div>

</body>
</html>
<script src="js/jquery-3.1.1.min.js"></script>
<script>
    //ajax删除
    function del(id){
        if(confirm("您确定要删除么")){
            $.ajax({
                method: "POST",
                url: "del",
                data: {id:id},
            }).done(function( msg ) {

                if(msg.code==100){
                    window.location.reload();
                }else{
                    alert("出现未知错误,删除失败");
                }
            });
        }

    }
    //ajax搜索
    $("#search").click(function(){
        //获取搜索的条件
        var data = {};
        data.is_hot = $("[name='is_hot']").val();
        data.is_sole = $("[name='is_sole']").val();
        $.ajax({
            method: "POST",
            url: "show",
            data:data,
        }).done(function( msg ){
            if(msg){
                $("tbody").empty();
                $(".page").empty();
                $("tbody").html(msg);
            }

        })
    })


    //即点即改
    $(document).on("click",".up",function(){

        var tex = $(this).text();
//        $(this).empty();
        $(this).parent().html("<input type='text' class='aup' value="+tex+">");
    })
    $(document).on("blur",".aup",function(){
        var obj=$(this);
        var text = $(this).val();
        var sm = $(this).parent().attr("val");
        var id=$(this).parent().attr("id");
//        alert(id);
        $.ajax({
            method: "POST",
            url: "sm",
            data:{sm:sm,text:text,id:id},
        }).done(function( data ){
            if(data.code==1){
                obj.parent().html("<span class='up'>"+text+"</span>");
            }else{
                alert("修改失败");
                obj.parent().html("<span class='up'>"+text+"</span>");
            }
        })

    })

//    $(document).ready(function(){
//        $(".up").click(function(){
//            var tex=$(this).text();
////            $(this).empty();
//            $(this).parent().html("<input type='text' class='aup' value="+tex+">");
//        });
//
//    });


</script>