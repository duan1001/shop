
    <?php $__currentLoopData = $arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($v->id); ?></td>
            <td  val="name" id="<?php echo e($v->id); ?>"><span class="up"><?php echo e($v->name); ?></span></td>
            <td><?php echo e($v->cate_name); ?></td>
            <td><?php echo e($v->disc); ?></td>
            <td val="is_hot" id="<?php echo e($v->id); ?>"><span class="up"><?php if($v->is_hot ==1){ echo '是';}else{echo '否';} ?></span></td>
            <td val="is_sole" id="<?php echo e($v->id); ?>"><span class="up"><?php if($v->is_sole ==1){ echo '是';}else{echo '否';} ?> </span></td>
            <td>
                <a href="javascript:;" onclick="del(<?php echo e($v->id); ?>)">删除</a>
                <a href="upd?id=<?php echo e($v->id); ?>">修改</a>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="page"><?php echo e($arr->links()); ?></div>