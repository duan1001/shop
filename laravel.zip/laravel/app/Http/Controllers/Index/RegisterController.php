<?php

namespace App\Http\Controllers\Index;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\models\Index\User;
use App\models\Index\Code;

class RegisterController extends Controller
{
    //注册首页
    public function register(){
        return view("index.register");
    }
    //检查唯一
    public function check(Request $request){
        //检查用户唯一
        $tel = $request->input("tel");
        //查询
        $res = User::where("u_tel",$tel)->first();

        if($res){
            $arr = [
                'code'=>0,
                'msg'=>"抱歉,该账号已被注册",
            ];
            return $arr;
        }else{
            $arr = [
                'code'=>1,
                'msg'=>"√",
            ];
            return $arr;
        }

    }
    //
    public function registerDo(Request $request){
        $post = $request->input();

        //验证唯一
        $res = User::where("u_tel",$post['tel'])->first();
//        var_dump($res);exit;
        if($res){
            $arr = [
                'code'=>0,
                'msg'=>"抱歉,该账号已被注册",
            ];
            return $arr;
        }
        if($post['pwd']!=$post['repwd']){
            $arr = [
                'code'=>0,
                'msg'=>"两次密码不一致",
            ];
            return $arr;
        }
        //查看输入的验证码与发送的验证码是否一致
        $where = [
            "code" =>$post['code'],
            "tel" =>$post['tel'],
            "status" =>0
        ];
        $time = time();
//        var_dump($where);
//        var_dump($post);die;
        $codeInfo = Code::where($where)->first();
//        var_dump($codeInfo);
//        die;
        if($codeInfo){
            //验证验证码失效与否
            if($time > $codeInfo->timeout){
                $arr = [
                    'code'=>0,
                    'msg'=>"验证码已失效"
                ];
                return $arr;
            }
        }else{
            //验证码与手机号不匹配
            $arr = [
                'code'=>0,
                'msg'=>"验证码错误"
            ];
            return $arr;
        }

        $data=[
            "u_pwd"=>md5($post['pwd']),
            'u_tel'=>$post['tel'],
            'reg_time'=>time()
        ];

//        var_dump($post);exit;
        $result = User::insert($data);
//        var_dump($result);exit;
        if($result){
            //把验证码的状态值修改成1(已用过);
            $where = [
                "code" =>$post['code'],
                "tel" =>$post['tel'],
            ];
//            var_dump($where);
            Code::where($where)->update(['status'=>1]);
            $arr = [
                'code'=>1,
                'msg'=>"注册成功"
            ];
            return $arr;
        }else{
            $arr = [
                'code'=>1,
                'msg'=>"注册失败"
            ];
            return $arr;
        }

    }


    //短息验证码
    public function message(Request $request){
        $tel = $request->input("tel");
        //发送的验证码
        $num = rand(1000,9999);
        //5分钟有效
        $timeout = time()+300;

        $obj = new \Send();
        //发送验证码的情况
        $code = $obj->show($tel,$num);
        var_dump($code);
        $arr = [
            "tel" =>$tel,
            'code' =>$num,
            'timeout' =>$timeout,
            'status' =>0
        ];
        if($code ==100){
            $res = Code::insert($arr);
            if($res){
                $codeInfo = [
                    "code" =>1,
                    "msg" =>"发送成功,请注意接收,有效期5分钟"
                ];
                return $codeInfo;
            }
        }else{
            $codeInfo = [
                "code" =>0,
                "msg" =>"验证码发送失败"
            ];
            return $codeInfo;
        }
    }



}
