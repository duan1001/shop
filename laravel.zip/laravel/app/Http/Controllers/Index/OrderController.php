<?php

namespace App\Http\Controllers\Index;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Index\Carts;
use App\Models\Index\Goods_attr;
use App\Models\Index\Goods;
use App\Models\Index\Order;
use App\Models\Index\Order_info;
use App\Models\Index\User_address;
use App\Models\Index\Order_address;

class OrderController extends Controller
{
    public function index(Request $request){                                    //点击结算进入的页面
        $u_id = session("id");

        $goods_id = $request->input("idval");    //接收购物车的id

        $totalPrice = 0;

            if (!$u_id) {
                $arr = [
                    "code" => 0,
                    "msg" => "未登录"
                ];
                return $arr;
            }

            foreach ($goods_id as $value) {     //验证是否下架及购买数量是否超过库存
//                echo $value;
                $where = [
                    "u_id" => $u_id,
                    "carts.goods_id" => $value,
                    "status" => 0
                ];
//                dump($where);exit;
                $goodsInfo = Carts::where($where)
                    ->join("goods", "goods.goods_id", "=", "carts.goods_id")
                    ->first();    //商品的信息

                if ($goodsInfo->is_on_sale == 0) {                                            //判断商品是否下架
                    return ["code" => 1, "msg" => "您所购买的" . $goodsInfo->goods_name . "已下架"];
                }

                if ($goodsInfo->goods_number < $goodsInfo->buy_number) {                       //判断商品购买数量是否超过库存量
                    return ["code" => 1, "msg" => "您所购买的" . $goodsInfo->goods_name . "超过库存量"];
                }

                $price = $goodsInfo->buy_number * $goodsInfo->shop_price;

                $totalPrice += $price;                                                        //求生成订单商品的总价

            }

            $order_sn = $this->setSn();                               //生成订单号

            $order_id = $this->addOrder($totalPrice, $order_sn);                              //添加到订单表

            $res = $this->addOrderInfo($goods_id, $order_id, $u_id, $order_sn);                  //添加到商品详情表

            $up = $this->setCarts($goods_id, $u_id);

            if ($order_id && $res && $up) {
                return ["code" => 3, "msg" => "订单生成成功","refre"=>$order_id];
            }

    }




    public function orderIndex( Request $request){
        $u_id = session("id");                                    //登录者

        $order_id = $request->input("order");                    //接收订单编号

        $goodsInfo = Order_info::where("order_id",$order_id)->get();                //获取该订单下的所有商品

        $where = [
            "u_id" =>$u_id,
            "default" =>1,
        ];

        $address = User_address::where($where)->first();

        if($address){
            $address = $address->toArray();
        }else{
            $address = [];
        }

        $num = count($address);

        return view("index.order.payment",["goodsInfo"=>$goodsInfo,"address"=>$address,"num"=>$num,"order_id"=>$order_id]);

    }


    public function checkLog( Request $request){

        $u_id = session("id");

        if( !$u_id ){

            return  ["code"=>2,"msg"=>"未登录"];
        }
    }

    public function addOrderAddress( Request $request){                               //添加订单地址表

        $u_id = session("id");

        $order_id = $request->input("order_id");

        $where = [
            "u_id" =>$u_id,
            "default" =>1
        ];

        $addressInfo = User_address::where( $where )->first();

        $received_address = $addressInfo->address . $addressInfo->sign_building;

        $arr = [
            "order_id"=>$order_id,
            "user_id" =>$u_id,
            "order_receive_name" =>$addressInfo->consignee,
            "receive_tel" =>$addressInfo->tel,
            "province_id" =>1,
            "city_id" =>3,
            "area_id"=>88,
            "receive_address"=>$received_address,
        ];

        $res = Order_address::insert( $arr );

        if($res){
            return ["code"=>4,"msg"=>"添加成功"];
        }else{
            return ["code"=>5,"msg"=>"添加失败"];
        }

    }




    public function setSn(){                                                      //生成订单号

        $order_sn = date("YmdHis",time()).rand(10000,99999);

        return $order_sn;
    }


    public function addOrder( $totalPrice,$order_sn ){                                 //添加到订单表
        $u_id = session("id");
        $arr = array(
            'order_sn'=>$order_sn,
            'u_id'=>$u_id,
            'order_amount'=>$totalPrice,
            'order_pay_type'=>1,
            'pay_status'=>1,
            'pay_way'=>1,
            'status'=>1,
            'c_time'=>time()
        );
        $res = Order::insertGetId( $arr );
        return $res;
    }

    public function addOrderInfo($idVal,$order_id,$u_id,$order_sn){                    //添加到订单商品详情表

        foreach($idVal as $val){
            $where = [
                "u_id"=>$u_id,
                "status"=>0,
                "carts.goods_id"=>$val
            ];
            $goodInfo = Carts::where( $where )
                      ->join("goods","goods.goods_id","=","carts.goods_id")
                      ->first();
            $arr = [
                "order_id"=>$order_id,
                "order_sn" =>$order_sn,
                "u_id" =>$u_id,
                "goods_id" =>$val,
                "buy_number" =>$goodInfo->buy_number,
                "goods_name" =>$goodInfo->goods_name,
                "goods_img" =>$goodInfo->goods_img,
                "goods_price" =>$goodInfo->shop_price,
            ];
            $res = Order_info::insert($arr);

        }
        return $res;

    }

    public function setCarts($idVal,$u_id){                                          //订单号生成时软删购物车
        $where = [
            "u_id" =>$u_id,
            "status" =>0
        ];

        $res = Carts::where( $where )->whereIn("goods_id",$idVal)->update(['status'=>1]);

        return $res;
    }








}
