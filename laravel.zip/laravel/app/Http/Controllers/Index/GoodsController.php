<?php

namespace App\Http\Controllers\Index;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Index\Goods;
use App\Models\Index\Category;
use App\Models\Index\Goods_gallery;
use App\Models\Index\Goods_attr;
use App\Models\Index\Carts;


class GoodsController extends Controller
{
    public function index(){
        //查询所有的商品分类
        $cateIno = Category::where("parent_id",0)->get();

        return view("index.allgoods",['cateInfo'=>$cateIno]);
    }

    //流加载调用方法
    public function goodsInfo(Request $request){

        $cate_id = $request->input("cate_id"); //cate分类

        $choose = $request->input("choose");  //选择是否热门 注:即将揭晓默认走的是在售卖状态的全部商品

        $price = $request->input("price");

        $price = $price=="up"?"asc":"desc";      //选择价格是上升还是降价

        $goodsInfo = Goods::where("is_on_sale",1);        //->orderBy("click_count","desc");

        if($cate_id){   //左侧选择分类

            $data = Category::get();

            $idAll = $this->getCateId($data,$cate_id);   //查看该分类下的子集分类的cate_id

            $idAll = is_array($idAll) ? $idAll : [];

            array_unshift($idAll,$cate_id);     //把自身的id放在前面

            $goodsInfo = $goodsInfo ->whereIn("cat_id",$idAll);
        }

        if($choose=="is_on_sale"){

            $goodsInfo = $goodsInfo->orderBy("click_count","desc");   //0代表热卖

        }elseif($choose=="is_hot"){    //上面选择热门...

            $goodsInfo = $goodsInfo->where("is_hot",0)->orderBy("click_count","desc");   //0代表热卖

        }elseif($choose=="is_new"){

            $goodsInfo = $goodsInfo->where("is_new",0)->orderBy("click_count","desc");   //0代表新品

        }elseif($choose=="price"){

            $goodsInfo = $goodsInfo->orderBy("shop_price",$price);   //默认降序

        }

        $goodsInfo = $goodsInfo->paginate(4);   //分页

        $page = $goodsInfo->lastPage();   //总的页码数

        $view = view("index.cateajax",['arr'=>$goodsInfo]);

        $arr['view'] = response($view)->getContent();  //装换格式

        $arr['page'] = $page;

        return $arr;

    }
    //获取一个分类下的所有子集分类
    public function getCateId($newData,$parent_id){

        static $data;
        if($newData){
            foreach($newData as $k=>$v){
                if($v['parent_id']==$parent_id){
                    $data[$k]=$v['cate_id'];

                    $this->getCateId($newData,$v['cate_id']);
                }
            }
        }
        return $data;
    }

    //查询商品详情
    public function goods(Request $request){

        $goods_id = $request->get("goods_id");    //接收商品的id

        $cate_id = $request->input("cate_id");   //商品的分类

        $goodsInfo = Goods::where("goods_id",$goods_id)
                   ->join("category","goods.cat_id","=","category.cate_id")
                   ->first();                                    //获取商品的信息

//        $goodsAttr = Goods_attr::where("goods_id",$goods_id);
        $goodsGollery = Goods_gallery::where("goods_id",$goods_id)->get()->toArray();    //查看该商品的所有图片

        $goodsImg[0]['img_url'] = $goodsInfo['goods_thumb'];     //将商品表里的图放到二维数组里

        $newArray = array_merge($goodsGollery,$goodsImg);       //将商品表里的图与商品相册表里的图合并

        $session_id = session("id");

        $cart_num = 0;

        if( $session_id ){              //查该用户下的所有商品
            $where = [
                "u_id"=>$session_id,
                "status" =>0
            ];

            $goods = Carts::where($where)->get()->toArray();

            $buyNum = array_column($goods,"buy_number");

            $cart_num = array_sum( $buyNum );

        }

        return view("index.goods.goodscontent",['goodsInfo'=>$goodsInfo,'newArray'=>$newArray,"cart_num"=>$cart_num]);
    }









}
