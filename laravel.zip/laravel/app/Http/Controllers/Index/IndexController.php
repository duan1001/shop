<?php

namespace App\Http\Controllers\index;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\models\Index\Goods;

class IndexController extends Controller
{
    public  function index(Request $request){
        //查询推荐商品
        $arr = Goods::where("is_rec",1)
            ->orderBy("goods_id","desc")
            ->take(2)
            ->get();

        return view("index.index",['arr'=>$arr]);
    }

    //流加载
    public function  load(){
        $data = Goods::where("is_best",0)
            ->orderBy("goods_id","desc")
            ->paginate(4);
        //获取总共的页码数
        $arr['page'] = $data->lastPage();
        $view = view("index.load",['data'=>$data]);
        $arr['view'] =response($view)->getContent();
        return $arr;
    }

}
