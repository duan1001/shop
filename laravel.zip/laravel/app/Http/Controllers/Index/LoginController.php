<?php

namespace App\Http\Controllers\Index;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\models\Index\User;

class LoginController extends Controller
{
    public function login(Request $request){
        return view("index.login");
    }

    public function loginDo(Request $request){
        $post = $request->input();
        $u_tel = $post['tel'];
        $u_pwd = md5($post['pwd']);
        $res = User::where("u_tel",$u_tel)->first();
        if(!$res){
            $arr = [
                'code'=>0,
                "msg"=>"账号或密码错误"
            ];
            return $arr;
        }else{
            $where = [
                "u_tel" => $u_tel,
                "u_pwd" =>$u_pwd,
            ];
//                var_dump($where);
            $res = User::where($where)->first();
            if($res){
                session(['id'=>$res->u_id,'u_tel'=>$res->u_tel]);
                //修改最后一次的登录时间
                $data = ['last_logintime'=>time()];
                User::where("u_id",$res->u_id)->update($data);
                $arr = [
                    'code'=>1,
                    "msg"=>"登录成功"
                ];
                return $arr;
            }else{
                $arr = [
                    'code'=>0,
                    "msg"=>"账号或密码错误"
                ];
                return $arr;
            }
        }

    }

    public function quit(Request $request){                  //退出

      $res =  $request->session()->forget("id");

           return ["code"=>1];
    }














}
