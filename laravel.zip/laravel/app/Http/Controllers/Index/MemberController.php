<?php

namespace App\Http\Controllers\Index;

use Illuminate\Http\Request;

use App\Http\Controllers\Controller;

use App\Models\Index\User_address;

use App\Models\Index\Region;

use App\Models\Index\Order;

use App\Models\Index\Order_address;

use App\Models\Index\Order_info;

use App\Models\Index\Goods;

class MemberController extends Controller
{
    public function index(Request $request){                        //用户表展示
        //获取是否登录
        $arr['id'] = $request->session()->get("id");

        $arr['name'] = $request->session()->get("u_tel");

//        var_dump($arr);
        return view("index.userpage",['arr'=>$arr]);
    }



    public function address( Request $request ){                      //登录者所有的收货地址

        $u_id = $request->session()->get("id");

        $address = User_address::where("u_id",$u_id)->get()->toArray();

        return view("index.member.address",["address"=>$address]);

    }



    public function addAddressIndex(  ){                   //添加收货地址展示

        return view("index.member.add_address");
    }


    public function addAddress( Request $request ){                                 //添加收货人执行方法

        $arr['consignee'] = trim($request->input("consignee"));                      //收件人

        $arr['tel'] = trim($request->input("tel"));                             //联系方式

        $arr['address'] = trim($request->input("address"));                             //地址

        $arr['default'] = intval($request->input("check"));                             //是否为默认地址

        $arr['sign_building'] = trim($request->input("sign_building"));              //详细地址

        $arr['u_id'] = session("id");                                                  //登录者

        if( $arr['default']==1){

            $res1 =$this->updateCheck( $arr['u_id'] );

        }

        $res2 = User_address::insert($arr);

        if($res2){
            return ["code"=>1,"msg"=>"添加成功"];
        }else{
            return ["code"=>0,"msg"=>"添加失败"];
        }

    }


    public function upAddressCheck( Request $request){                                  //及点及改(修改默认地址)

        $address_id = $request->input("address_id");

        $u_id = session("id");

        $res1 = $this->updateCheck( $u_id );

        $res2 = User_address::where("address_id",$address_id)->update(['default'=>1]);

        if(!$res1 || !$res2){
            return ["code"=>1,"msg"=>"修改失败"];
        }

    }


    public  function delAddress(Request $request){

        $address_id = $request->input("address_id");

       $res =  User_address::where("address_id",$address_id)->delete();

        if($res){
            return ["code"=>1,"msg"=>"删除成功"];
        }else{
            return ["code"=>0,"msg"=>"删除失败"];
        }

    }

    public  function  updateCheck( $u_id ){                            //取消该用户下的默认地址

        $where = [
            "u_id" =>$u_id,
            "default" =>1
        ];

        $res = User_address::where( $where )->update(['default'=>0]);

        return $res;

    }


    public function updateAddress(Request $request){                                                  //修改地址展示

        $address_id = $request->input("address_id");                                  //获取address_id

        $addressInfo = User_address::where( "address_id",$address_id)->first();

        return view("index.member.updateAddress",['addressInfo'=>$addressInfo]);

    }

    public function updateAddressDo( Request $request){                                         //修改执行

        $address_id = $request->input("address_id");

        $arr['consignee'] = trim($request->input("consignee"));                      //收件人

        $arr['tel'] = trim($request->input("tel"));                             //联系方式

        $arr['address'] = trim($request->input("address"));                             //地址

        $arr['default'] = intval($request->input("check"));                             //是否为默认地址

        $arr['sign_building'] = trim($request->input("sign_building"));              //详细地址

        $arr['u_id'] = session("id");                                                  //登录者

        if( $arr['default']==1){

            $res1 =$this->updateCheck( $arr['u_id'] );

        }

        $res2 = User_address::where("address_id",$address_id)->update($arr);

        if($res2){
            return ["code"=>1,"msg"=>"修改成功"];
        }else{
            return ["code"=>0,"msg"=>"修改失败"];
        }
    }

    public function orderList(Request $request){                                            //查看用户的所有订单

        $u_id = $request->session()->get("id");

        $orderInfo = Order::where("u_id",$u_id)->get();                                     //查看所有订单信息

        $goodsInfo = [];

        $num = count($orderInfo);

        if( $num){

            $orderInfo =  $orderInfo->toArray();
        }else{                                                 //该用户下没有购物记录;
            $where = [
                "is_on_sale" =>1,                              //1代表售卖状态
                "is_hot" =>0                                   //0代表热卖
            ];
            $goodsInfo = Goods::where( $where )->take(4)->get();             //获取在售卖商品的前4条
        }

        return view("index.member.orderList",['orderInfo'=>$orderInfo,"num"=>$num,"goodsInfo"=>$goodsInfo]);

    }

    public function  orderGoodsInfo(Request $request){                                     //查看一个订单下所有的商品信息

        $u_id = $request->session()->get("id");

        $u_tel = $request->session()->get("u_tel");

        $order_id = $request->get("order");

        $goodsInfo = Order::where("order.order_id",$order_id)                                       //订单表与订单详情表双表联查

                   ->join("order_info","order.order_id","=","order_info.order_id")

                   ->get();

        return view("index.member.orderGoodsInfo",["goodsInfo"=>$goodsInfo,"u_tel"=>$u_tel]);

    }

    public function set(){

        return view("index.member.set");
    }






}
