<?php

namespace App\Http\Controllers\Index;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Index\Carts;
use App\Models\Index\Goods_attr;
use App\Models\Index\Goods;

class CartsController extends Controller
{

    public function index( Request $request ){          //购物车展示
        $session_id = $request->session()->get("id");

        if(!$session_id){
            return ["code"=>0];   //未登录状态
        }

        $where = [
            "u_id" =>$session_id,
            "status" =>0
        ];
        $goodsInfo = Carts::where( $where )
                   ->join("goods","goods.goods_id","=","carts.goods_id")
                   ->get()
                   ->toArray();         //查购物车里的所有数据及商品的库存

        $totalPrice = 0;

        if( $goodsInfo ){
            //处理价格
            foreach($goodsInfo as $v){
                $price =  $v['buy_number'] * $v["shop_price"];
                $totalPrice = $totalPrice + $price;
            }
        }
        $where1 = [
            "is_on_sale"=>1,
            "is_hot" =>0
        ];

        $hotInfo = Goods::where( $where1 )->orderBy("goods_id","desc")->take(4)->get();

        return view("index.carts.buycarts",["goodsInfo"=>$goodsInfo,"totalPrice"=>$totalPrice,"hotInfo"=>$hotInfo]);
    }


    public function add(Request $request){           //点击加入购物车

        $session_id = $request->session()->get("id");   //判断是否登录

        if(! $session_id){

            return ["code"=>0];
        }
        $goods_id = $request->input("goods_id");

        $where = [
            'goods_id'=>$goods_id,
            'is_on_sale' =>1
        ];
        $goodsInfo = Goods::where( $where )->where("goods_number",">",0)->first();   //判断商品上下架

        if(!$goodsInfo){
            $arr = [
                "code"=>1,
                "msg"=>"抱歉,该商品已下架"
            ];
            return $arr;
        }

        $where2 = [
            "u_id" =>$session_id,
            "status" =>0
        ];
        $cartInfo = Carts::where( $where2 )->where("goods_id",$goods_id)->first();  //判断该用户的购物车里有没有该商品

        if($cartInfo){  //有值  数量加一

            $buy_number = $cartInfo['buy_number']+1;
            $where = [
                "goods_id"=>$goods_id,
                "u_id" =>$session_id
            ];
            $time = time();
            $arr = [
                'buy_number'=>$buy_number,
                "update_time"=>$time
            ];
            $res = Carts::where( $where )->update(['buy_number'=>$buy_number]);

            if($res){
                return ['code'=>2,'msg'=>"修改购物车成功"];        //添加到购物车
            }else{
                return ['code'=>3,'msg'=>"添加购物车失败"];       //未添加到购物车
            }
        }else{
            $goods = Goods::where("goods_id",$goods_id)->first();

            $time = time();

            $arr =[
                "u_id"=>$session_id,
                "goods_id"=>$goods_id,
                "goods_name"=>$goods['goods_name'],
                'shop_price'=>$goods['shop_price'],
                'goods_img'=>$goods['goods_img'],
                "buy_number" =>1,
                "add_time"=>$time,
                "update_time"=>$time,
                'status'=>0

            ];

            $res = Carts::insert( $arr );

            if($res){

                return ['code'=>2,'msg'=>"添加购物车成功"];        //修改到购物车

            }else{

                return ['code'=>3,'msg'=>"添加购物车失败"];       //未修改到购物车
            }
        }

    }

    public function updateNum(Request $request){     //点击加减

        $goods_id = $request->input("goods_id");       //获取数量加一的商品id

        $buyNum = $request->input("buyNum");           //修改的数量

        $u_id = session("id");

        $where = [
            "goods_id"=>$goods_id,

            "u_id" =>$u_id


        ];
        $arr = [
            "buy_number" =>$buyNum,

            "update_time"=>time(),
        ];

        $res =Carts::where( $where )->update($arr);           //修改商品购买数量

        if($res){
            return ["code"=>1];
        }

    }

//    单删
    public function delete(Request $request){
        $goods_id = $request ->input("goods_id");

        $idval = $request ->input("idval");

        $u_id = session("id");

        $where = [
            'u_id' => $u_id,
            "goods_id" => $goods_id
        ];

        if($goods_id){
            $res = Carts::where( $where )->update(['status'=>1]);
        }else{
            $res = Carts::where("u_id",$u_id)->whereIn( "goods_id",$idval )->update(['status'=>1]);
        }


        if($res){
            return ["code"=>1,'msg'=>"删除成功"];
        }



    }



















}
