<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Good extends Controller
{
    public function show(){
        echo "this is a controller";
    }
}
