<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\models\Goods as Good;

class Goods extends Controller
{

    //添加展示页面
    public  function add(){
        //查询分类表
        $sql = "select * from cate";
        $arr = DB::select($sql);
//        var_dump($arr);exit;
        return view("goods.add")->with(['arr'=>$arr]);
    }

    //添加执行
    public function save(Request $request){
        $arr = $request->input();
        $arr['is_del']=0;
//        var_dump($arr);exit;
        //添加入库
        $id = DB::table("goods")->insertGetId($arr);
        var_dump($id);
    }

    //展示页面
    public function index(Request $request){

        $arr = DB::table("goods")
            ->where("is_del",0);
//            ->join("cate","goods.cate_id","=","cate.cate_id")
//            ->paginate(2);
//        if($request->ajax()){
            $is_hot = $request->input("is_hot");
            $is_sole = $request->input("is_sole");

        if($is_hot && $is_sole){
            $where = [
                "is_hot"=>$is_hot,
                "is_sole" => $is_sole
            ];
            $arr = $arr->where($where);
        }
//
//        }
        $arr = $arr->join("cate","goods.cate_id","=","cate.cate_id")
             ->paginate(2);
        if($request->ajax()){
            if($arr){
                return view("goods.search",['arr'=>$arr]);
            }
        }

//        var_dump($arr);exit;
        return view("goods.index")->with(['arr'=>$arr]);
    }


//    //搜索
//    public function search(Request $request){
//        $is_hot = $request->input("is_hot")?$request->input("is_hot"):"";
//        $is_sole = $request->input("is_sole")?$request->input("is_sole"):"";
//        $where = [
//            "is_hot"=>$is_hot,
//            "is_sole" => $is_sole
//        ];
//        $arr = DB::table("goods")
//            ->where("is_del",0)
//            ->where($where)
//            ->join("cate","goods.cate_id","=","cate.cate_id")
//            ->paginate(2);
//        return view("goods.index")->with(['arr'=>$arr]);
//    }




    //删除页面
    public function delete(Request $request){
        $id = $request->input("id");
//        var_dump($id);
        //修改状态
        $res = DB::table("goods")->where("id",$id)->update(['is_del'=>1]);
//        var_dump($res);
        if($res){
            return ['code'=>100];
        }
    }

    //修改页面
    public  function update(Request $request){
        $id = $request->input("id");
        //查询分类
        $cateInfo = DB::table("cate")->get();
//        var_dump($cateInfo);
        //双表查询
        $arr = DB::table("goods")
             ->join("cate","cate.cate_id","=","goods.cate_id")
            ->where("id",$id)
            ->get();
//        var_dump($arr);exit;
        return view("goods.update",['arr'=>$arr,'cateInfo'=>$cateInfo]);
    }

    //修改执行页面
    public  function edit(Request $request){

        $arr = $request->input();
//        var_dump($name) ;
        $arrInfo['name'] = trim($arr['name']);
        $arrInfo['id'] = intval($arr['id']);
        $arrInfo['cate_id'] = intval($arr['cate_id']);
        $arrInfo['disc'] = trim($arr['disc']);
        $arrInfo['is_hot'] = intval($arr['is_hot']);
        $arrInfo['is_sole'] = intval($arr['is_sole']);
//        $arrInfo['is_del'] = 0;
        //修改
        $res = Good::where("id",$arrInfo['id'])
             ->update($arrInfo);
        if($res){
            $arr = array(
                'status'=>1,
                'msg'=>"成功",
            );
        }else {
            $arr = array(
                'status' => 0,
                'msg' => "失败",
            );
        }
//
        return $arr;
    }
    public function some(Request $request){
        $key = $request->input("sm");
        $val = $request->input("text");
        $id = $request->input("id");
        if($val=="是"){
            $val="1";
        }else if($val=="否"){
            $val="2";
        }
        $arr = [
            $key=>$val
        ];
        $res = Good::where("id",$id)->update($arr);
        if($res){
            return ['code'=>1,"msg"=>"修改成功"];
        }else{
            return ['code'=>0,"msg"=>"修改失败"];
        }
    }










}
