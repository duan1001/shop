<?php

namespace App\Http\Controllers\order;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class Order extends Controller
{
//    public function add(Request $request){
//        $arr = $request->input();
//        var_dump($arr);
//    }
//    public function add($id,$age){
//
//        echo $id;
//        echo $age;
//    }
//    public function show(){
//        return view("order.order");
//    }
//    public function edit(){
////        return redirect();
//        //url辅助函数
//        $url = url("admin\ur");
////        echo $url;exit;
//        return redirect($url);
//    }
//    //使用url辅助函数
//    public function del(){
//        echo "url辅助函数的使用";
//    }
    //添加
    public function add(){
        $sql = "insert into user(name,age) values('liS','22')";
        $res = DB::insert($sql);
        var_dump($res);
    }
    //查询
    public function index(){
        $sql = "select * from user";
        $arr = DB::select($sql);
        var_dump($arr);
    }
    //修改
    public  function update(){
        $sql = "update user set name='lili',age='33' where id=1";
        $res = DB::update($sql);
        var_dump($res);
    }
    //删除
    public function delete(){
        $sql = "delete from user where id=1";
        $res = DB::delete($sql);
        var_dump($res);
    }





}
