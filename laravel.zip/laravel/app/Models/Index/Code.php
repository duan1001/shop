<?php

namespace App\Models\Index;

use Illuminate\Database\Eloquent\Model;

class Code extends Model
{
    protected $table = "code";
    protected $primaryKey = "code_id";
    public $timestamps = false;
}

