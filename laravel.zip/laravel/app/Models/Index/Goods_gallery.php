<?php

namespace App\Models\Index;

use Illuminate\Database\Eloquent\Model;

class Goods_gallery extends Model
{
    protected $table="goods_gallery";
    protected $primaryKey = "img_id";
    public $timestamps = false;

}
