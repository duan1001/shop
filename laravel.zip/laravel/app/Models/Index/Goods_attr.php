<?php

namespace App\Models\Index;

use Illuminate\Database\Eloquent\Model;

class Goods_attr extends Model
{
    protected $table = "goods_attr";
    protected $primaryKey = "goods_attr_id";
    public $timestamps = false;
}
