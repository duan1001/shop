<?php

namespace App\Models\Index;

use Illuminate\Database\Eloquent\Model;

class Carts extends Model
{
    protected $table="carts";
    protected  $primaryKey = "cart_id";
    public  $timestamps = false;

}
