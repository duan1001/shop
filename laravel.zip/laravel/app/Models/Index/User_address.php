<?php

namespace App\Models\Index;

use Illuminate\Database\Eloquent\Model;

class User_address extends Model
{
    protected $table="user_address";
    protected  $primaryKey = "address_id";
    public $timestamps = false;
}
