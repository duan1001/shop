<?php

namespace App\Models\Index;

use Illuminate\Database\Eloquent\Model;

class Order_address extends Model
{
    protected $table="order_address";
    protected  $primaryKey = "id";
    public $timestamps = false;
}
