<?php

namespace App\Models\Index;

use Illuminate\Database\Eloquent\Model;

class Order_info extends Model
{
    protected $table="order_info";
    protected  $primaryKey = "id";
    public $timestamps = false;
}
