<?php

namespace App\Index;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    //
}
