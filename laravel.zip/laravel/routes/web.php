<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
//Route::get("hello/{id}",function($id){
//    echo $id;
//    echo "welcome to laravel";
//});
////路由到控制器里的某个方法
//Route::get("show","Good@show");
////路由到控制器里某个文件下的某个方法
//Route::get("add","order\Order@add");
////路由到视图层
//Route::get("see",function(){
//    return view("good");
//});
////单纯从路由到视图层
//Route::get("a",function(){
//    return view("order\order");
//});
////路由到控制器到视图层
//Route::get("b","order\Order@show");
//
////路由加判断
//Route::get('s/{id}',function($id){
//    if($id>10){
//        return redirect("Http://www.baidu.com");
//    }else{
//        return view("good");
//    }
//});
////控制器里面接收参数
//Route::get("d/{id}/{age}","order\Order@add");
//
////路由前加前缀
//Route::prefix('admin')->group(function () {
//    Route::get('users', function () {
//        // Matches The "/admin/users" URL
//        echo "前缀";
//    });
//    Route::get("see","order\Order@add");
//    Route::get("ur","order\Order@del");
//});
//Route::get("u","order\Order@edit");
//
//Route::get("e","order\Order@add");
//Route::get("sel","order\Order@index");
//Route::get("upd","order\Order@update")->middleware("tt");
//Route::get("del","order\Order@delete");


//Route::get("add","goods@add");
//Route::post("save","goods@save");
//Route::any("show","goods@index");
//Route::post("del","goods@delete");
//Route::get("upd","goods@update");
//Route::post("update","goods@edit");
//Route::any("search","goods@search");
//Route::post("sm","goods@some");
//Route::get("demo",function(){
//    return view("demo");
//});

//h5项目

//路由前加前缀
//Route::prefix('index')->group(function () {

Route::get("index","index\IndexController@index"); //主页面
Route::get("user","index\MemberController@index");//用户
Route::get("register","index\RegisterController@register");//注册
Route::post("check","index\RegisterController@check");//检查
Route::post("reg","index\RegisterController@registerDo");//注册执行
Route::any("log","index\LoginController@login");//登录
Route::post("loginDo","index\LoginController@loginDo");//登录执行
Route::post("send","index\RegisterController@message");//发送验证码
Route::get("goods","index\GoodsController@index");//全部商品
Route::get("load","index\IndexController@load");//流加载
Route::any("goodscontent","index\GoodsController@goods");//商品详情
Route::any("goodsInfo","index\GoodsController@goodsInfo");//商品详情
Route::get("goodstip",function(){          //潮购声明
    return  view("index.goods.shoptip");
});
Route::any("buycarts","index\CartsController@index");   //购物车展示
Route::post("addcarts","index\CartsController@add");   //购物车添加
Route::post("updateNum","index\CartsController@updateNum");   //购物车列表点击加减修改购买数量
Route::post("del","index\CartsController@delete");     //单删.全删
Route::any("payInfo","index\OrderController@index");   //支付页面
Route::any("orderIndex","index\OrderController@orderIndex");   //订单页面
Route::get("address","index\MemberController@address");   //地址信息展示
Route::post("checkLog","index\OrderController@checkLog");   //添加收货地址展示页
Route::post("addAddress","index\MemberController@addAddress");   //添加收货地址执行
Route::get("addAddressIndex","index\MemberController@addAddressIndex");   //添加收货地址展示页
Route::post("upAddressCheck","index\MemberController@upAddressCheck");   //添加收货地址展示页
Route::any("addOrderAddress","index\OrderController@addOrderAddress");   //添加收货地址展示页
Route::get("updateAddress","index\MemberController@updateAddress");   //添加收货地址展示页
Route::post("updateAddressDo","index\MemberController@updateAddressDo");   //添加收货地址展示页
Route::post("delAddress","index\MemberController@delAddress");   //添加收货地址展示页
Route::get("orderList","index\MemberController@orderList");   //查看潮购记录
Route::get("orderGoodsInfo","index\MemberController@orderGoodsInfo");   //查看潮购订单详细记录
Route::get("set","index\MemberController@set");   //查看潮购订单详细记录
Route::post("quit","index\LoginController@quit");   //查看潮购订单详细记录
//});
