
    @foreach($arr as $k=>$v)
        <tr>
            <td>{{$v->id}}</td>
            <td  val="name" id="{{$v->id}}"><span class="up">{{$v->name}}</span></td>
            <td>{{$v->cate_name}}</td>
            <td>{{$v->disc}}</td>
            <td val="is_hot" id="{{$v->id}}"><span class="up"><?php if($v->is_hot ==1){ echo '是';}else{echo '否';} ?></span></td>
            <td val="is_sole" id="{{$v->id}}"><span class="up"><?php if($v->is_sole ==1){ echo '是';}else{echo '否';} ?> </span></td>
            <td>
                <a href="javascript:;" onclick="del({{$v->id}})">删除</a>
                <a href="upd?id={{$v->id}}">修改</a>
            </td>
        </tr>
    @endforeach
    <div class="page">{{$arr->links()}}</div>