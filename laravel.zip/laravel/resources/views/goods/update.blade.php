<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>修改</title>
</head>
<script src="js/jquery-3.1.1.min.js"></script>
<body>
<form action="#" method="post" id="submit">

    <table>
        @foreach($arr as $key=>$val)
            {{--<input type="hidden" value="{{$val->id}}" name="id">--}}
            <tr>
                <td>名称</td>
                <td><input type="text" name="name" value="{{$val->name}}" ></td>
            </tr>
            <tr>
                <td>分类</td>
                <td>
                    <select name="cate_id" id="">
                        <option value="">请选择</option>
                        @foreach($cateInfo as $k=>$v)
                            <option value="{{$v->cate_id}}" @if($val->cate_id == $v->cate_id)selected @endif>{{$v->cate_name}}</option>
                        @endforeach
                    </select>
                </td>
            </tr>
            <tr>
                <td>描述</td>
                <td><textarea name="disc" id="" cols="30" rows="10">
                {{$val->disc}}
            </textarea>
                </td>
            </tr>
            <tr>
                <td>是否热销</td>
                <td>
                    <input type="radio" name="is_hot" value="1" @if($val->is_hot == 1) checked @endif>是
                    <input type="radio" name="is_hot" value="2" @if($val->is_hot == 2) checked @endif>否
                </td>
            </tr>
            <tr>
                <td>是否上架</td>
                <td>
                    <input type="radio" name="is_sole" value="1" @if($val->is_sole == 1) checked @endif>是
                    <input type="radio" name="is_sole" value="2" @if($val->is_sole == 2) checked @endif>否
                </td>
            </tr>
        @endforeach
        <tr colspan="2">
            <td>
                <input type="button" value="修改" idv="{{$val->id}}" id="a">
                {{--<input type="submit" value="修改">--}}
            </td>
        </tr>
    </table>
</form>
</body>
</html>
<script>

    $('#a').click(function(){
        //定义一个json
        var data={};
        //将数据放在json中
        data.id = $("#a").attr("idv");
        data.name = $("[name='name']").val();
        data.cate_id = $("[name='cate_id']").val();
        data.disc = $("[name='disc']").val();
        data.is_hot = $("[name='is_hot']:checked").val();
        data.is_sole = $("[name='is_sole']:checked").val();
//        console.log(data);
//        var data=$('#submit').serialize();
        $.ajax({
            method: "POST",
            url: "update",
            data: data,
        }).done(function( msg ) {
//            alert(msg);
            if(msg.status==1){
                alert("修改成功");
                window.location.href="show";
            }else{
                alert("出现未知错误,添加失败");
            }
        });

    })
</script>