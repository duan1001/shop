<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>练习</title>
</head>
<script src="js/jquery-3.1.1.min.js"></script>
<body>
<form action="#" method="post" id="submit">
<table>
    <tr>
        <td>名称</td>
        <td><input type="text" name="name"></td>
    </tr>
    <tr>
        <td>分类</td>
        <td>
            <select name="cate_id" id="">
                <option value="">请选择</option>
                @foreach($arr as $k=>$v)
                    <option value="{{$v->cate_id}}">{{$v->cate_name}}</option>
                @endforeach
            </select>
        </td>
    </tr>
    <tr>
        <td>描述</td>
        <td><textarea name="disc" id="" cols="30" rows="10">

            </textarea>
        </td>
    </tr>
    <tr>
        <td>是否热销</td>
        <td>
            <input type="radio" name="is_hot" value="1">是
            <input type="radio" name="is_hot" value="2">否
        </td>
    </tr>
    <tr>
        <td>是否上架</td>
        <td>
            <input type="radio" name="is_sole" value="1">是
            <input type="radio" name="is_sole" value="2">否
        </td>
    </tr>
    <tr colspan="2">
        <td>
            <input type="button" value="提交" id="a">
        </td>
    </tr>
</table>
</form>
</body>
</html>
<script>
    $('#a').click(function(){
        var data=$('#submit').serialize();
        $.ajax({
              method: "POST",
              url: "save",
              data: data,
        }).done(function( msg ) {
            if(msg){
                window.location.href="show";
            }else{
                alert("出现未知错误,添加失败");
            }
        });

    })
</script>