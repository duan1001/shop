<!DOCTYPE html>
<html>
<head>
    <meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
    <title>潮购记录</title>
    <meta content="app-id=984819816" name="apple-itunes-app" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, user-scalable=no, maximum-scale=1.0" />
    <meta content="yes" name="apple-mobile-web-app-capable" />
    <meta content="black" name="apple-mobile-web-app-status-bar-style" />
    <meta content="telephone=no" name="format-detection" />
    <link href="css/comm.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="css/buyrecord.css">
    <script src="layui/layui.js"></script>


</head>
<body>

<!--触屏版内页头部-->
<div class="m-block-header" id="div-header">
    <strong id="m-title">潮购记录</strong>
    <a href="javascript:history.back();" class="m-back-arrow"><i class="m-public-icon"></i></a>
    <a href="/" class="m-index-icon"><i class="buycart"></i></a>
</div>
@if($num)
<div class="recordwrapp">
    @foreach($orderInfo as $v)
    <div class="buyrecord-con clearfix">
        <div class="record-img fl">
            <img src="images/goods2.jpg" alt="">
        </div>
        <div class="record-con fl">
            <h3>订单号:&nbsp;&nbsp; &nbsp;&nbsp;{{$v['order_sn']}}</h3>
            {{--<p class="winner">获得者：<i>终于中了一次</i></p>--}}
            <div class="clearfix">
                <div class="win-wrapp fl">
                    <p class="w-time">订单生成时间:&nbsp;&nbsp; &nbsp;&nbsp;{{date("Y-m-d H:m:i",$v['c_time'])}}</p>
                    <p class="w-chao">支付状态 : &nbsp;&nbsp; &nbsp;&nbsp;@if($v['status'] ==1)未支付@elseif($v['status'] ==2)已支付@elseif($v['status'] ==3)已确认@elseif($v['status'] ==4)备货中@elseif($v['status'] ==5)发货中@elseif($v['status'] ==6)已发货@endif</p>
                </div>
                <div class="fr">
                    @if($v['status'] ==1)
                    <a href="/orderIndex?order={{$v['order_id']}}">查看详情</a>
                    @else
                    <a href="/orderGoodsInfo?order={{$v['order_id']}}">查看详情</a>
                    @endif
                </div>
            </div>
        </div>
    </div>
    @endforeach
</div>
@else

<div class="nocontent">
    <div class="m_buylist m_get">
        <ul id="ul_list">
            <div class="noRecords colorbbb clearfix">
                <s class="default"></s>您还没有购买商品哦~
            </div>
            <div class="hot-recom">
                <div class="title thin-bor-top gray6">
                    <span><b class="z-set"></b>人气推荐</span>
                    <em></em>
                </div>
                <div class="goods-wrap thin-bor-top">
                    <ul class="goods-list clearfix">
                        @if($goodsInfo)
                        @foreach($goodsInfo as $v)
                        <li>
                            <a href="/goodscontent?goods_id={{$v->goods_id}}" class="g-pic">
                                <img src="{{URL::asset('uploads/'.$v->goods_img)}}" width="136" height="136">
                            </a>
                            <p class="g-name">
                                <a href="https://m.1yyg.com/v44/products/23458.do">(第<i>{{$v->goods_id}}</i>潮){{$v->goods_name}}</a>
                            </p>
                            <ins class="gray9">价值:￥{{$v->shop_price}}</ins>
                            <div class="btn-wrap">
                                <div class="Progress-bar">
                                    <p class="u-progress">
                                        <span class="pgbar" style="width:1%;">
                                            <span class="pging"></span>
                                        </span>
                                    </p>
                                </div>
                                <div class="gRate" data-productid="23458">
                                    <a href="javascript:;" class="buy" goodsId="{{$v->goods_id}}"><s></s></a>
                                </div>
                            </div>
                        </li>
                        @endforeach
                        @endif
                    </ul>
                </div>
            </div>
        </ul>
    </div>
</div>
@endif

<script src="js/jquery-1.11.2.min.js"></script>
<script>
    //加入购物车
    layui.use("layer",function(){
        var layer = layui.layer;
        //加入购物车
        $(document).on("click",".buy",function(){
            var goods_id = $(this).attr("goodsId");
//                console.log(goods_id);
//                return false;
            var data = {};
            var url = "/addcarts";
            var refre = "/orderList";
//            var cartNum = $(".cart b").text();
            data.goods_id = goods_id;
            $.ajax({
                type: "post",
                url: url,
                data: data,
                dataType: "json",
            }).done(function (msg) {
//                cartNum = parseInt(cartNum) + parseInt(1);
//                    0:未登录 1:商品下架   2  添加购物车成功  3 添加购物车失败
                if (msg.code == 0) {
                    layer.confirm("执行该操作需先登录,确定要登录么?", {title: "您未登录"}, function () {
                        window.location.href = "/log?refre=" + refre;
                    })
                }
                if (msg.code == 1) {
                    layer.msg(msg.msg, {time: 10000});
                }
                if (msg.code == 2) {
                    layer.msg(msg.msg, {time: 10000});
                }
                if (msg.code == 3) {
                    layer.msg(msg.msg, {time: 10000});

                }
            })


        })


    })
</script>



</body>
</html>
