<div class="footer clearfix">
    <ul>
        <li class="f_home"><a href="/v41/index.do" class="hover"><i></i>潮购</a></li>
        <li class="f_announced"><a href="/goods" ><i></i>所有商品</a></li>
        <li class="f_single"><a href="/v41/post/index.do" ><i></i>最新揭晓</a></li>
        <li class="f_car"><a id="btnCart" href="javascript:;" ><i></i>购物车</a></li>
        <li class="f_personal"><a href="user" ><i></i>我的潮购</a></li>
    </ul>
</div>
<script>
    //点击购物车
    $("#btnCart").click(function(){

        var url = "/buycarts";
        var refre = "/buycarts";
        $.ajax({
            type:"post",
            url :url,
            data :"",
            success:function(msg){
                if(msg.code==0){
                    layer.confirm("您未登录,确定要登录么?",{title:"温馨提示"},function(){
                        window.location.href = "/log?refre="+refre
                    })
                }else{
                    window.location.href="/buycarts";
                }
//                        success结尾
            }
        })
    })
</script>