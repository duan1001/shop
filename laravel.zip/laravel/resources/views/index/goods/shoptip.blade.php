<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, user-scalable=no, maximum-scale=1.0">
    <meta content="yes" name="apple-mobile-web-app-capable">
    <meta content="black" name="apple-mobile-web-app-status-bar-style">
    <meta content="telephone=no" name="format-detection">
    <title>潮购声明</title>
    <link rel="stylesheet" href="css/common.css">
    <link href="css/comm.css" rel="stylesheet" type="text/css">
</head>
<body>
<!--触屏版内页头部-->
<div class="m-block-header" id="div-header">
    <strong id="m-title">潮购声明</strong>
    <a href="javascript:history.back();" class="m-back-arrow"><i class="m-public-icon"></i></a>
    <a href="/" class="m-index-icon"></a>
</div>
<div id="loadingwrapp">
    <div class="backimg"></div>
    <div class="shoptip agreement">
        <h3>一：手机、电脑、小数码及电器类等</h3>
        <p>1、获得的商品将在2-15个工作日发出，部分预售、定制或紧俏商品发货时间会相对延长哦；</p>
        <p>2、以获得的商品为准，如标注为颜色随机的商品则无法挑选颜色，我们将随机颜色发货；</p>
        <p>3、商品均为包邮，物流无法到达区域，用户可选择换购本商城同等价位商品(一件或多件)，亦可补差价换购高价位商品；</p>
        <h3>二：汽车类</h3>
        <p>1、获得的汽车已包含购置税、上牌费、交强险费用，不含过户费及商业险费用；</p>
        <p>2、目前揭晓的汽车需前往666潮人购指定车行提车，666潮人购亦会尽量安排获得者在当地或离收货地最近城市提车；</p>
        <p>3、由于车辆区域保护政策，具体上牌地点以车行提供为准；</p>
        <p>4、汽车获得者填写的收货人姓名需与其身份证一致；</p>
        <p>5、商城出售的具体车型及配置以商品标题的型号版本和车行的实物为准；</p>
        <h3>三：副食品、日用品及母婴类等</h3>
        <p>1、获得的商品将在2-15个工作日发出；</p>
        <p>2、部分时令商品请及时完善地址，因季节局限性，也许超时即已无货，届时只能换购平台其他商品；</p>
        <p>3、商品均为包邮，物流无法到达区域，用户可选择换购本商城同等价位商品(一件或多件)，亦可补差价换购高价位商品；</p>
        <h3>四：充值卡、虚拟商品类</h3>
        <p>1、用户获得后请前往“个人中心-获得的商品”，提取卡密；
        <p>2、提取失败时请稍后再试，或联系客服400-666-2110；</p>
        <h3>五：温馨提示</h3>
        <p>1、666潮人购商业模式的初衷是希望消费者在网购的同时能够享受娱乐，用户需根据自身实际情况进行适当的消费；</p>
        <p>2、商品获得者拥有商品10年免费使用权；
            666潮人购对所有商品及活动在法律范围内拥有最终解释权；</p>
        <p class="center">感谢您对666潮人购的支持与谅解，祝您潮购愉快！</p>
    </div>
</div>
<script src="js/jquery-1.8.3.min.js"></script>
<script>

    var deviceWidth = document.documentElement.clientWidth;
    document.documentElement.style.fontSize = document.documentElement.clientWidth / 7.5 + 'px';
    // if(deviceWidth > 750) deviceWidth = 750;
    document.documentElement.style.fontSize = deviceWidth / 7.5 + 'px';
</script>
</body>
</html>