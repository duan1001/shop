<?php
    $arr = array(
        array("id"=>1,"age"=>6),
        array("id"=>2,"age"=>34),
        array("id"=>3,"age"=>20),
        array("id"=>4,"age"=>18),
    );

    foreach($arr as $v){
        $sort[] = $v['age'];
    }
    sort($sort);
    foreach($arr as $v){
        $arrNew[$v['age']] = $v;
    }
    foreach($sort as $v){
        $newArray[] = $arrNew[$v];
    }
var_dump($newArray);
?>